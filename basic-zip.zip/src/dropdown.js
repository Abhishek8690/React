import data from './countries.json';
import { useState } from 'react';


function Dropdown() {
    const [state, setstate] = useState();
    const [city , setcity] = useState();
    let i;
    // console.log(data)
    return(
        <>
            <select onChange={(e)=> setstate(e.target.value) }>
                {data.details.map((entry) =>{
                    return(
                        <option key={entry.value}> {entry.name} </option>
                    );
                })}
            </select>
            <select>
                {data.details.map((entry,val) =>{
                    // console.log(entry.cities[0],entry.cities[1])
                    // data.details.map((property,i) =>{
                    //     return( 
                    //         <option key={entry.name}>{property.cities[i]}</option>
                    //     )
                    // }) 
                    
                    if(entry.name === state){
                        console.log(entry.cities)
                        for( i=0; i<entry.cities.length+1; i++)
                            {console.log(entry.cities[i],i)
                                return( 
                                        <option key={entry.name}>{entry.cities[i]}</option>
                                    )
                            }
                    }         
                   
                })}
            </select>

        </>
    )
}
export default Dropdown;