// import { useReducer } from 'react';
// function Password() {
//     let MESSAGE = {
//         EMPTY: "password cannot be empty",
//         CORRECT: "password is correct",
//         INCORRECT: "password is incorrect",
//         ATLEAST: "put atleast" + {state}.value.length + "characters."
//     };
//     function reducer(state, action) {
        
//     }
//     const [state , dispatch] = useReducer(reducer,{ value: '' , message: MESSAGE.EMPTY});
//     function check() {

//     }

//     return (
//         <>
//             <input type="password" value={state.value} onChange={e => {e.target.value}} />
//             <button type="button" onClick={check}>Check</button>
//             <p>{state.message}</p>
//          </>
//     );
// }
// export default Password;