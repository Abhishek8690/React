import { useState } from 'react';
function Password_reduce() {
    let warning = {
        invalid: "Invalid Password",
        empty: "password cannot be empty",
        less_char: "Password must be atleast 9 characters long.",
        valid: "correct password"
    };
    let styles = {
        text: {
            invalid: "red",
            valid: "green",
            less_char: "orange",
            empty: "blue"
        }
    };
    let password = {
        value: "Fifa@2023",
        max_try: 3,
        length: 9
    };
    const [state, setstate] = useState("");
    const [message, update_msg] = useState(warning.empty);
    const [color, change_color] = useState(styles.text.empty);
    function check() {
        console.log(state)
        if(state === password.value) {
            update_msg(warning.valid);
            change_color(styles.text.valid);
        }
        else {
                if(state.length !== password.length ) {
                    update_msg(warning.less_char);
                    change_color(styles.text.less_char);
                }
                if(state !== password.value ) {
                    update_msg(warning.invalid);
                    change_color(styles.text.invalid);
                }   
            }
    }
  return(
    <>
        <input type="password" value={state} onChange={(e) => { setstate(e.target.value)}} />   
        <button type="button" onClick={check} >Enter</button>
        <p style={{color:color}} className='warning'>{message}</p>
    </>
  );  
}
export default Password_reduce;