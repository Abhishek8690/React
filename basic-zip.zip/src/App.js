import './App.css';
import State from './state';
import Inc from './inc_dec';
import Todo from './todo';
import Demo from './demo';
import Effect from './effect';
import Time from './time';
import Property from './property';
import Input_theme from './input-dark-light';
import Calculator from './calculator';
import Reducer from './reducer';
import Light_dark from './reducer_dark_light';
import Password from './password';
import Fill from './fill';
import Password_reduce from './password_in_reduce';
import Dropdown from './dropdown';

function App() {
  return (
    <>
      {/* <Todo/> */}
      {/* <Inc/> */}
      {/* <State/> */}
      {/* <Demo /> */}
      {/* <Effect /> */}
      {/* <Time /> */}
      {/* <Property /> */}
      {/* <Input_theme /> */}
      {/* <Calculator /> */}
      {/* <Reducer /> */}
      {/* <Password /> */}
      {/* <Fill /> */}
      {/* <Light_dark /> */}
      {/* <Password_reduce /> */}
      <Dropdown />
    </>
  );
}

export default App;
