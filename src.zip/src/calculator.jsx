import { useState, useReducer } from 'react';
import './calculator.css';
function Calculator() {
    return(
        <div className="wrapper container">
            <div className="display-section row">
                {/* <input type="text" className="col-12" id="input-box" value={state} onChange={(e) => 
                    addexpression(e.target.value)
                } /> */}
                <div className='col-12 display'>
                    <div className='input-data'>input</div>
                    <div className='output-data'>output</div>
                </div>
            </div>
            <div className="input-section">
                <div className='row row-one'>
                    <button className="col-4"  type="button">1</button>
                    <button className="col-4"   type="button">2</button>
                    <button className="col-4"  type="button">3</button>
                </div>
                <div className='row row-two'>
                    <button className="col-4"   type="button">4</button>
                    <button className="col-4"  type="button">5</button>
                    <button className="col-4"  type="button">6</button>
                </div>
                <div className='row row-three'>
                    <button className="col-4"   type="button">7</button>
                    <button className="col-4"   type="button">8</button>
                    <button className="col-4"  type="button">9</button>
                </div>
                <div className='row row-four'>
                    <button className="col-4"   type="button">0</button>
                    <button className="col-4"   type="button">+</button>
                    <button className="col-4"   type="button">-</button>
                </div>
               <div className='row row-five'>
                    <button className="col-4"   type="button">*</button>
                    <button className="col-4"  type="button">/</button>
                    <button className="col-4"   type="button">=</button>
               </div>
               
            </div>

        </div>
    )
}
export default Calculator;