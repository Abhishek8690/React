import { useState, useEffect } from 'react';
function Effect() {

const [ effect, change_effect ] = useState("posts");
const [ items, setitems ] = useState([]);
useEffect(() => {
    console.log("use effect running");
//     fetch('./data.json')
//     .then(response => response.json())
//     .then(data => setitems(data));
// }, [effect]
})

return(
    <>  
        <button onClick={() => {change_effect("posts")}}>posts</button>
        <button onClick={() => {change_effect("comments")}}>comments</button>
        <button onClick={() => {change_effect("exit")}}>exit</button>
        <p>{effect}</p>
        {/* <p>{items.map(item => {
            return <span>{JSON.stringify(item)}</span>
        })}</p> */}
    </>
);
}

export default Effect;