import { useState } from 'react';
const color_array = [];
function Fill() {
    const [color , fillcolor] = useState();
    function applycolor() {
        fillcolor(color);
    }
    return(
        <>
            <div className='color-the-div' style={{background : color}} >
                <input type="text" value={color} />
                <button type="button" onClick={(e) => {fillcolor(e.target.value)}}>Apply color</button>
            </div>
        </>
    );
}
export default Fill;
