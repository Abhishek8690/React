import { useReducer } from 'react';
function Light_dark() {
    const theme = {
        light: "white",
        dark: "black"
    };
    const [ state, dispatch ] = useReducer(reducer , 'white');
    function reducer( state, action ) {
        console.log(action,state)
        switch(action) {
            case theme.light :
                return theme.light;
            case theme.dark :
                return theme.dark;
            default:
                return state;    
        }
    }
return(
    <>
        <p style={{background: state}} className="p-text">Use the below buttons for Light and dark themes</p>
        <button onClick={dispatch(theme.light)} type="button">Light</button>
        <button onClick={dispatch(theme.dark)} type="button">Dark</button>
    </>
);

}
export default Light_dark;