import { useState } from 'react';
function Todo() {
    const [newitem, setnewitem] = useState("");
    const [todos, settodos] = useState([]);
    function handlesubmit(e) {
        console.log("handlesubmit");
        e.preventDefault();
        settodos(currenttodos => {
            return [...currenttodos,
            {
                id: crypto.randomUUID(), title: newitem,
                completed: false
            },
            ]
        })
        setnewitem("");
        console.log(todos);
    }
    function deleteentry(id) {
        settodos(currenttodos => {
            return currenttodos.filter(todo => todo.id !== id)
        })
    }
    console.log(todos, newitem);
    return (
        <div className='wrapper'>
            <form className="todo-form App" onSubmit={handlesubmit}>
                <label htmlFor='input-box'>text area to fill</label>
                <input 
                    type="text" 
                    className="inp-box" 
                    id="input-box" 
                    defaultValue={newitem}
                    name="input-box"
                    onChange={(e) => setnewitem(e.target.value)}
                />
                <button type="submit" className="btn btn-primary">Add</button>
            </form >
            <h1>todo list</h1>
            <ul className='inputarea' >
                {todos.map(todo => {
                    return (
                        <li key={todo.id}>
                            <label>
                                <input type="checkbox" defaultValue={todo.completed}></input>
                                {todo.title}
                            </label>
                            <button type="button" id='delete-btn' onClick={() => deleteentry(todo.id)}>delete</button>
                        </li>
                    )
                })}
            </ul>
        </div>
    );
}

export default Todo;
