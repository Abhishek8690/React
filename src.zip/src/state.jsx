import { useState } from 'react';

function State() {
    const [theme , settheme] = useState("white");
    if(theme === "black")
    {
     var p_color = "white";
    }
    return (
        <div className='wrapper' style={{ background : theme}}>
        <p style = {{color : p_color }} >Just click on the below buttons to switch to Light / Dark theme.</p>
        <button style={{ color: p_color , background : theme}} className="light-btn" onClick={() => {
          settheme("white");
        }}>Light </button>
        <button style={{ color : p_color , background : theme}}   className="dark-btn" onClick={() => {
          settheme("black");
        }}> Dark </button>
      </div>
    );
}
export default State;