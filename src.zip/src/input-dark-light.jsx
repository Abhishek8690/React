import './theme_style.css';
import { useState } from 'react';


function Input_theme() {
    const [ color, applycolor ] = useState();
    // let inp_color = color;
    function setcolor(color) {
        applycolor(color)
    }
    return (
        <div className="wrapper-div" style = {{ background : color }}>
            <input type="text" value={color}></input>
            <button type="button" onClick={e => setcolor(e.target.value)}>Apply</button>
        </div>
    );
}
export default Input_theme;